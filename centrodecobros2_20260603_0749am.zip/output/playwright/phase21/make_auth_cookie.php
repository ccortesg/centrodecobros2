<?php
require __DIR__ . '/../../../vendor/autoload.php';
$app = require __DIR__ . '/../../../bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();
$request = Illuminate\Http\Request::create('/');
$app->instance('request', $request);
$session = $app['session']->driver();
$request->setLaravelSession($session);
$session->start();
$user = App\User::findOrFail(1);
Illuminate\Support\Facades\Auth::guard('web')->login($user);
$session->save();
$cookieName = config('session.cookie');
$sessionValue = Illuminate\Cookie\CookieValuePrefix::create($cookieName, $app['encrypter']->getKey()) . $session->getId();
echo $app['encrypter']->encrypt($sessionValue, false);